<?php
    $db_server = "localhost";
    $db_name = "root";
    $db_password = "";
    $db = "complete_login_register_form";

    $conn = mysqli_connect($db_server, $db_name, $db_password, $db);

    if (!$conn) {
        echo "Connection Failed.";
    }
?>