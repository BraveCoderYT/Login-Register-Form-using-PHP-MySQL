<?php
    session_start();

    if (isset($_SESSION['email'])) {
        header("Location: welcome.php");
    }

    include 'config.php';

    if (isset($_POST['submit'])) {
        $email = $_POST['email'];
        $password = md5($_POST['password']);

        $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) == 1) {
            $sql1 = "SELECT * FROM users";
            $result1 = mysqli_query($conn, $sql1);
            if (mysqli_num_rows($result1) > 0) {
                $row = mysqli_fetch_assoc($result1);
                $_SESSION['full_name'] = $row['full_name'];
            }

            $_SESSION['email'] = $email;
            $_SESSION['password'] = $password;
            
            header("Location: welcome.php");
        }else {
            echo "<script>alert('Login Unsuccessfully.');</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login Form | Brave Coder</title>
</head>
<body>
    <div class="wrapper">
        <div class="title">Login Form</div>
        <div class="sub-title">Login for Free</div>
        <form action="" method="post" class="form">
            <div class="inputBox">
                <input type="email" name="email" placeholder="Email">
            </div>
            <div class="inputBox">
                <input type="password" name="password" placeholder="Password">
            </div>
            <button type="submit" name="submit" class="btn">Login</button>
            <p>Account already exists <a href="register.php">Register</a></p>
        </form>
    </div>
</body>
</html>