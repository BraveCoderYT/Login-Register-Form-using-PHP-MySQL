<?php
    include 'config.php';
    if (isset($_POST['submit'])) {
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        $c_password = md5($_POST['c_password']);

        if (empty($full_name) | empty($email) | empty($password) | empty($c_password)) {
            echo "<script>alert('All Field is Required.');</script>";
        }else {
            if ($password == $c_password) {
                $email_query = "SELECT * FROM users WHERE email='$email'";
                $email_result = mysqli_query($conn, $email_query);
                if (mysqli_num_rows($email_result) > 0) {
                    echo "<script>alert('This email already exists.');</script>";
                }else {
                    $sql = "INSERT INTO users (full_name, email, password, c_password) VALUES ('$full_name', '$email', '$password', '$c_password')";
                    $result = mysqli_query($conn, $sql);

                    if ($result) {
                        header("Location: index.php");
                    }else {
                        // echo "<script>alert('Register Unsuccessfully.');</script>";
                        echo "Error: " . $sql . mysqli_error($conn);
                    }
                }
            }else {
                echo "<script>alert('Password or Confirm Password not match.');</script>";
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Register | Brave Coder</title>
    <style>
        .wrapper {
            min-height: 400px;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="title">Register</div>
        <div class="sub-title">Register for Free</div>
        <form action="" method="post" class="form">
            <div class="inputBox">
                <input type="text" name="full_name" placeholder="Full Name">
            </div>
            <div class="inputBox">
                <input type="email" name="email" placeholder="Email">
            </div>
            <div class="inputBox">
                <input type="password" name="password" placeholder="Password">
            </div>
            <div class="inputBox">
                <input type="password" name="c_password" placeholder="Confirm Password">
            </div>
            <button type="submit" name="submit" class="btn">Register</button>
            <p>Account already exists <a href="index.php">Login</a></p>
        </form>
    </div>
</body>
</html>