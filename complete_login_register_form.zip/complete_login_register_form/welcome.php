<?php
    session_start();
    if (!isset($_SESSION['email'])) {
        header("Location: index.php");
    }
?>

<h1><?php echo "Hi " . $_SESSION['full_name']; ?></h1>